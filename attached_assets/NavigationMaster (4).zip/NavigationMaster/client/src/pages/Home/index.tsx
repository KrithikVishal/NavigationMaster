import React from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import LogoSection from "./components/LogoSection";
import Features from "./components/Features";
import CTA from "./components/CTA";
import Testimonials from "./components/Testimonials";
import Pricing from "./components/Pricing";
import FAQ from "./components/FAQ";
import FinalCTA from "./components/FinalCTA";
import Footer from "./components/Footer";

const Home: React.FC = () => {
  return (
    <div className="font-sans text-gray-800 bg-gray-50">
      <Header />
      <main>
        <Hero />
        <LogoSection />
        <Features />
        <CTA />
        <Testimonials />
        <Pricing />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
};

export default Home;
