import React from "react";
import { Link } from "wouter";
// Direct import with relative path
import heroImage from "../../../assets/hero-image.svg";

const Hero: React.FC = () => {
  return (
    <section className="relative pt-16 pb-24 overflow-hidden">
      {/* Background gradient elements */}
      <div className="absolute top-0 right-0 -mr-96 -mt-64">
        <div className="w-[600px] h-[600px] rounded-full bg-primary/10 opacity-30 blur-3xl"></div>
      </div>
      <div className="absolute bottom-0 left-0 -ml-96 -mb-64">
        <div className="w-[600px] h-[600px] rounded-full bg-secondary-100 opacity-30 blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 lg:pr-12 mb-10 lg:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Simplify Your Workflow with{" "}
              <span className="bg-gradient-to-r from-primary to-secondary-500 bg-clip-text text-transparent">
                Smart Automation
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              All-in-one platform to streamline your tasks, enhance collaboration, and boost productivity across your entire organization.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link 
                href="/signup" 
                className="inline-flex justify-center items-center py-3 px-6 rounded-lg bg-primary hover:bg-primary/90 text-white font-medium transition-colors"
              >
                Get Started Free
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="ml-2 h-5 w-5" 
                  viewBox="0 0 20 20" 
                  fill="currentColor"
                >
                  <path 
                    fillRule="evenodd" 
                    d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" 
                    clipRule="evenodd" 
                  />
                </svg>
              </Link>
              <Link 
                href="/demo" 
                className="inline-flex justify-center items-center py-3 px-6 rounded-lg border border-gray-300 hover:border-gray-400 text-gray-700 font-medium transition-colors"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="mr-2 h-5 w-5" 
                  viewBox="0 0 20 20" 
                  fill="currentColor"
                >
                  <path 
                    fillRule="evenodd" 
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" 
                    clipRule="evenodd" 
                  />
                </svg>
                Watch Demo
              </Link>
            </div>
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2">
                <div className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center overflow-hidden">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-6 h-6 text-gray-500">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center overflow-hidden">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-6 h-6 text-gray-500">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center overflow-hidden">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-6 h-6 text-gray-500">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <span className="text-sm text-gray-500">Trusted by 10,000+ teams worldwide</span>
                <div className="flex items-center mt-1">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <svg 
                        key={i}
                        xmlns="http://www.w3.org/2000/svg" 
                        className="h-4 w-4 text-yellow-400" 
                        viewBox="0 0 20 20" 
                        fill="currentColor"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <span className="ml-1 text-sm font-medium text-gray-600">4.9/5 (2,500+ reviews)</span>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:w-1/2 relative">
            <div className="bg-white p-4 shadow-xl rounded-2xl border border-gray-200">
              <div className="rounded-lg w-full overflow-hidden">
                <img 
                  src={heroImage} 
                  alt="Dashboard visualization" 
                  className="w-full h-auto"
                />
              </div>
            </div>
            <div className="absolute -right-8 -bottom-8 bg-white p-4 rounded-xl shadow-lg border border-gray-200 w-48">
              <div className="flex items-center mb-2">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-4 w-4 text-green-500" 
                    viewBox="0 0 20 20" 
                    fill="currentColor"
                  >
                    <path 
                      fillRule="evenodd" 
                      d="M3 3a1 1 0 000 2h10a1 1 0 100-2H3zm0 4a1 1 0 000 2h6a1 1 0 100-2H3zm0 4a1 1 0 100 2h8a1 1 0 100-2H3zm8 0a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1z" 
                      clipRule="evenodd" 
                    />
                  </svg>
                </div>
                <span className="font-medium text-gray-700">Analytics</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full mb-1">
                <div className="h-2 bg-green-500 rounded-full w-3/4"></div>
              </div>
              <div className="text-xs text-gray-500">Productivity up 32%</div>
            </div>
            <div className="absolute -left-8 -top-8 bg-white p-4 rounded-xl shadow-lg border border-gray-200 w-48">
              <div className="flex items-center mb-2">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-4 w-4 text-blue-500" 
                    viewBox="0 0 20 20" 
                    fill="currentColor"
                  >
                    <path 
                      fillRule="evenodd" 
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" 
                      clipRule="evenodd" 
                    />
                  </svg>
                </div>
                <span className="font-medium text-gray-700">Tasks</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">Completed</span>
                <span className="text-blue-500 font-medium">24/30</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
