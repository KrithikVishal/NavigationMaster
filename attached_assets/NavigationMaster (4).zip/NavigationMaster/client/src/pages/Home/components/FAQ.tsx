import React from "react";

interface FAQItem {
  question: string;
  answer: string;
}

const FAQ: React.FC = () => {
  const faqs: FAQItem[] = [
    {
      question: "How does the 14-day free trial work?",
      answer:
        "Our free trial gives you full access to all features for 14 days. No credit card required to start. At the end of your trial, you can choose the plan that's right for your team or cancel without any charges.",
    },
    {
      question: "Can I change plans later?",
      answer:
        "Yes, you can upgrade, downgrade, or cancel your plan at any time. If you upgrade, the new rate will be prorated for the remainder of your billing cycle. If you downgrade, the new rate will apply to your next billing cycle.",
    },
    {
      question: "Is there a limit to how many team members I can add?",
      answer:
        "The Starter plan allows up to 10 team members. The Professional and Enterprise plans allow unlimited team members, though pricing is based on the number of users.",
    },
    {
      question: "How secure is your platform?",
      answer:
        "Security is our top priority. We use industry-standard encryption, regular security audits, and role-based access controls. Enterprise plans include additional security features like SSO and advanced data protection.",
    },
    {
      question: "Do you offer discounts for nonprofits or educational institutions?",
      answer:
        "Yes, we offer special pricing for nonprofit organizations, educational institutions, and startups. Contact our sales team to learn more about eligibility and discounts.",
    },
  ];

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently asked questions</h2>
          <p className="text-xl text-gray-600">Find answers to common questions about our platform.</p>
        </div>
        
        <div className="max-w-3xl mx-auto space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
              <div className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
