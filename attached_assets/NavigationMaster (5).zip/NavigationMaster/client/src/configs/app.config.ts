const appConfig = {
  apiPrefix: '/api',
  defaultPath: '/', // Changed from '/hello' to '/'
  authenticatedEntryPath: '/dashboard',
  unAuthenticatedEntryPath: '/',
  tourPath: '/',
  locale: 'en',
  enableMock: false,
};

export default appConfig;
