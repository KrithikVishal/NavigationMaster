import sharedRoutes from './sharedRoutes';

interface Route {
  key: string;
  path: string;
  component: string;
  authority: string[];
}

const routes: Route[] = [
  {
    key: 'dashboard',
    path: '/dashboard',
    component: 'Dashboard',
    authority: ['admin', 'user'],
  },
  {
    key: 'profile',
    path: '/profile',
    component: 'Profile',
    authority: ['admin', 'user'],
  },
  {
    key: 'settings',
    path: '/settings',
    component: 'Settings',
    authority: ['admin', 'user'],
  },
  {
    key: 'admin',
    path: '/admin',
    component: 'Admin',
    authority: ['admin'],
  },
  ...sharedRoutes, // Include shared routes for authorized users
];

export default routes;
