import sharedRoutes from './sharedRoutes';

interface Route {
  key: string;
  path: string;
  component: string;
  authority: string[];
}

const authRoutes: Route[] = [
  {
    key: 'login',
    path: '/login',
    component: 'Login',
    authority: [],
  },
  {
    key: 'signup',
    path: '/signup',
    component: 'Signup',
    authority: [],
  },
  {
    key: 'forgot-password',
    path: '/forgot-password',
    component: 'ForgotPassword',
    authority: [],
  },
  {
    key: 'reset-password',
    path: '/reset-password',
    component: 'ResetPassword',
    authority: [],
  },
  ...sharedRoutes, // Include shared routes for unauthorized users
];

export default authRoutes;
