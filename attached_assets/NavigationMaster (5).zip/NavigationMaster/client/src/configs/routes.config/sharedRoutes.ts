interface Route {
  key: string;
  path: string;
  component: string;
  authority: string[];
}

const sharedRoutes: Route[] = [
  {
    key: 'home',
    path: '/',
    component: 'Home',
    authority: [],
  },
  {
    key: 'about',
    path: '/about',
    component: 'About',
    authority: [],
  },
  {
    key: 'pricing',
    path: '/pricing',
    component: 'Pricing',
    authority: [],
  },
  {
    key: 'features',
    path: '/features',
    component: 'Features',
    authority: [],
  },
  {
    key: 'contact',
    path: '/contact',
    component: 'Contact',
    authority: [],
  },
];

export default sharedRoutes;
