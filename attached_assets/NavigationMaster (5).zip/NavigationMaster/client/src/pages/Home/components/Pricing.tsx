import React from "react";
import { Link } from "wouter";

interface PricingTier {
  name: string;
  description: string;
  price: string;
  period: string;
  features: string[];
  callToAction: string;
  callToActionLink: string;
  highlighted?: boolean;
  badge?: string;
}

const Pricing: React.FC = () => {
  const pricingTiers: PricingTier[] = [
    {
      name: "Starter",
      description: "Perfect for small teams getting started",
      price: "$12",
      period: "/user/month",
      features: [
        "Up to 10 team members",
        "Basic workflow automation",
        "5GB storage",
        "Email support",
      ],
      callToAction: "Get Started",
      callToActionLink: "/signup",
    },
    {
      name: "Professional",
      description: "Ideal for growing teams needing more power",
      price: "$24",
      period: "/user/month",
      features: [
        "Unlimited team members",
        "Advanced workflow automation",
        "25GB storage",
        "Priority support",
        "Advanced analytics",
      ],
      callToAction: "Get Started",
      callToActionLink: "/signup",
      highlighted: true,
      badge: "Most Popular",
    },
    {
      name: "Enterprise",
      description: "Advanced features for large organizations",
      price: "$48",
      period: "/user/month",
      features: [
        "Everything in Professional",
        "Custom integrations",
        "Unlimited storage",
        "24/7 phone & email support",
        "Enterprise security features",
      ],
      callToAction: "Contact Sales",
      callToActionLink: "/contact",
    },
  ];

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple, transparent pricing</h2>
          <p className="text-xl text-gray-600">Choose the plan that works best for your team. All plans include a 14-day free trial.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {pricingTiers.map((tier, index) => (
            <div
              key={index}
              className={`bg-white rounded-xl ${
                tier.highlighted
                  ? "border-2 border-primary shadow-lg relative transform md:-translate-y-4"
                  : "border border-gray-200 shadow-sm"
              } overflow-hidden`}
            >
              {tier.badge && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <span className="bg-primary text-white text-xs font-bold px-4 py-1 rounded-full uppercase">
                    {tier.badge}
                  </span>
                </div>
              )}
              <div className="p-6">
                <h3 className="font-semibold text-xl mb-2">{tier.name}</h3>
                <p className="text-gray-600 mb-4">{tier.description}</p>
                <div className="mb-4">
                  <span className="text-4xl font-bold">{tier.price}</span>
                  <span className="text-gray-600">{tier.period}</span>
                </div>
                <ul className="space-y-3 mb-6">
                  {tier.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-primary mt-1 mr-3"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  href={tier.callToActionLink}
                  className={`block w-full py-3 px-4 rounded-lg ${
                    tier.highlighted
                      ? "bg-primary hover:bg-primary/90 text-white"
                      : "border border-primary text-primary hover:bg-primary/5"
                  } text-center font-medium transition-colors`}
                >
                  {tier.callToAction}
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
